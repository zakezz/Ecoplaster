

function virgule(string)
	{
		if(string !='')
		{
			return string.replace(',', '.');
		}	
	return string;
}



function checkEmail(mailVal) {
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!filter.test(mailVal)) {
		alert('Votre adresse email est invalide');
		return false;
	} else {
		return true;
	}
}


function hide(id)  {
	document.getElementById(id).style.display='none';
}

function show(id){
	document.getElementById(id).style.display='table-row';
}

function menufacade(){ 
	var nbrFacade = $('Nombre_de_facades').val();
	for(i=1;i<=nbrFacade;i++){
		var facadeId ='facade'+i;
		$('#'+facadeId).show();
	}
	for(i=8;i>nbrFacade;i--){
		var facadeId ='facade'+i;
		$('#'+facadeId).hide();
	}
}


function calculSurface() {
	var total = 0;
	for(i=1;i<=8;i++){
		var totalSurface = 0;
		var pignonId ='facade_avec_pignon_'+i;
		var largeurId ='Largeur_facade_'+i;
		var hauteurId ='Hauteur_facade_'+i;
		var hauteurPignonId ='WF'+ (26+i) +'_Hauteur_pignon_'+i;
		var surfaceTotal ='surface_facade_'+i;
		
		if($('input[type=radio][name='+pignonId+']:checked').val()=="oui"){
			if(virgule($("#"+surfaceTotal).val())!=0){
				totalSurface = virgule($("#"+surfaceTotal).val())*1;
			}else{
				if(virgule($("#"+largeurId).val()) != 0 && virgule($("#"+hauteurId).val()) != 0){
					var hauteurPignon = virgule($("#"+hauteurPignonId).val())*1;
					var largeur = virgule($("#"+largeurId).val())*1;
					var hauteur = virgule($("#"+hauteurId).val())*1;
					totalSurface = largeur * ((hauteur+hauteurPignon)/2);
					}
				}
		}else{
			if(virgule($("#"+surfaceTotal).val())!=0){
				totalSurface = $("#"+surfaceTotal).val()*1;
			}else{
				if(virgule($("#"+largeurId).val()) != 0 && virgule($("#"+hauteurId).val()) != 0){
					var largeur = virgule($("#"+largeurId).val())*1;
					var hauteur = virgule($("#"+hauteurId).val())*1;
					totalSurface = largeur * hauteur;
				}
			}
		}
		total = Math.round((total + totalSurface));
	}
	$("Surface_totale").val(total);
} 



$(function(){
	$('#images').MultiFile({
		accept:'gif|jpg|GIF|JPG|jpeg|png|PNG|PDF|pdf|JPEG', max:4, STRING:{
			remove:'Supprimer',
			selected:'Selectionnez: $file',
			denied:'Le format est invalide $ext!',
			duplicate:'Vous avez dèjà uploader cette image:\n$file!'
			}
	});
	});


