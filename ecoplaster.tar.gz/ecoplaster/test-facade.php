<!DOCTYPE html">
<html lang="fr">
  <head>
    <meta charset="utf-8" />
    
    <link rel="stylesheet" href="css/style.css">
    <title>Devis - Ecoplaster</title>
    
	<script type="text/javascript" src="//code.jquery.com/jquery-3.0.0.min.js"></script>
	<script src="//code.jquery.com/jquery-1.10.2.js"></script>
	<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script src="js/eco.js"></script>
    
  </head> 

<body>	
	<div id="facades" style="display: table-row;">
		<div class="title">Description des façades</div>
		<table>
			<tr>
				<td class="PBStatic">Nombre de fa&ccedil;ades :</td>
				<td><select name="WF26_Nombre_de_facades" onchange="menufacade();" id="WF26_Nombre_de_facades"><option value="0">0</option>
                                                                                 <option value="1">1</option>
																				 <option value="2">2</option>
                                                                                 <option value="3">3</option>
                                                                                 <option value="4">4</option>
                                                                                 <option value="5">5</option>
                                                                                 <option value="6">6</option>
                                                                                 <option value="7">7</option>
                                                                                 <option value="8">8</option>
   				</select></td>
                <td colspan="2"><input type="button" value="comment faire vos mesures des façades ?" onclick="window.open('aide.html','wclose','width=620,height=415,toolbar=no,status=no,left=20,top=30')"></td>
			</tr>
			<tr>
            	<td></td>
				<td class="PBStatic-facade">Type de fa&ccedil;ade</td>
			</tr>
			<tr id="facade1">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 1 :</td>
				<td>Pignon : non <input type="radio"
					id="WF27_facade_avec_pignon_1" name="WF27_facade_avec_pignon_1"
					value="non" checked="checked" onclick="hide('pignon1');"/> oui <input type="radio" id="WF27_facade_avec_pignon_1"
					name="WF27_facade_avec_pignon_1" value="oui"
					onclick="show('pignon1');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF27_Largeur_facade_1" name="WF27_Largeur_facade_1" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF27_Hauteur_facade_1" name="WF27_Hauteur_facade_1" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon1" style="display: none;">Hauteur pignon : <input
					type="text" size="5px" id="WF27_Hauteur_pignon_1"
					name="WF27_Hauteur_pignon_1" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface1">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF27_surface_facade_1"
					name="WF27_surface_facade_1" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade2" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 2 :</td>
				<td>Pignon : non <input type="radio"
					id="WF28_facade_avec_pignon_2" name="WF28_facade_avec_pignon_2"
					value="non" checked="checked" onclick="hide('pignon2');"/> oui <input type="radio" id="WF28_facade_avec_pignon_2"
					name="WF28_facade_avec_pignon_2" value="oui"
					onclick="show('pignon2');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF28_Largeur_facade_2" name="WF28_Largeur_facade_2" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF28_Hauteur_facade_2" name="WF28_Hauteur_facade_2" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon2" style="display: none;">Hauteur pignon : <input type="text" size="5px" id="WF28_Hauteur_pignon_2"
					name="WF28_Hauteur_pignon_2" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface2" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF28_surface_facade_2"
					name="WF28_surface_facade_2" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade3" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 3 :</td>
				<td>Pignon : non <input type="radio"
					id="WF29_facade_avec_pignon_3" name="WF29_facade_avec_pignon_3"
					value="non" checked="checked" onclick="hide('pignon3');"/> oui <input type="radio" id="WF29_facade_avec_pignon_3"
					name="WF29_facade_avec_pignon_3" value="oui"
					onclick="show('pignon3');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF29_Largeur_facade_3" name="WF29_Largeur_facade_3" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF29_Hauteur_facade_3" name="WF29_Hauteur_facade_3" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon3" style="display: none;">Hauteur pignon : <input
					type="text" size="5px" id="WF29_Hauteur_pignon_3"
					name="WF29_Hauteur_pignon_3" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface3" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF29_surface_facade_3"
					name="WF29_surface_facade_3" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade4" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 4 :</td>
				<td>Pignon : non <input type="radio"
					id="WF30_facade_avec_pignon_4" name="WF30_facade_avec_pignon_4"
					value="non" checked="checked" onclick="hide('pignon4');"/> oui <input type="radio" id="WF30_facade_avec_pignon_4"
					name="WF30_facade_avec_pignon_4" value="oui"
					onclick="show('pignon4');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF30_Largeur_facade_4" name="WF30_Largeur_facade_4"
					value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF30_Hauteur_facade_4" name="WF30_Hauteur_facade_4" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon4" style="display: none;">Hauteur pignon : <input
					type="text" size="5px" id="WF30_Hauteur_pignon_4"
					name="WF30_Hauteur_pignon_4" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface4" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF30_surface_facade_4"
					name="WF30_surface_facade_4" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade5" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 5 :</td>
				<td>Pignon : non <input type="radio"
					id="WF31_facade_avec_pignon_5" name="WF31_facade_avec_pignon_5"
					value="non" checked="checked" onclick="hide('pignon5');"/> oui <input type="radio" id="WF31_facade_avec_pignon_5"
					name="WF31_facade_avec_pignon_5" value="oui"
					onclick="show('pignon5');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF31_Largeur_facade_5" name="WF31_Largeur_facade_5" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF31_Hauteur_facade_5" name="WF31_Hauteur_facade_5" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon5" style="display: none;">Hauteur pignon : <input type="text" size="5px" id="WF31_Hauteur_pignon_5"
					name="WF31_Hauteur_pignon_5" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface5" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF31_surface_facade_5"
					name="WF31_surface_facade_5" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade6" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 6 :</td>
				<td>Pignon : non <input type="radio"
					id="WF32_facade_avec_pignon_6" name="WF32_facade_avec_pignon_6"
					value="non" checked="checked" onclick="hide('pignon6');"/> oui <input type="radio" id="WF32_facade_avec_pignon_6"
					name="WF32_facade_avec_pignon_6" value="oui"
					onclick="show('pignon6');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF32_Largeur_facade_6" name="WF32_Largeur_facade_6" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF32_Hauteur_facade_6" name="WF32_Hauteur_facade_6" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon6" style="display: none;">Hauteur pignon : <input type="text" size="5px" id="WF32_Hauteur_pignon_6"
					name="WF32_Hauteur_pignon_6" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface6" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF32_surface_facade_6"
					name="WF32_surface_facade_6" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade7" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 7 :</td>
				<td>Pignon : non <input type="radio"
					id="WF33_facade_avec_pignon_7" name="WF33_facade_avec_pignon_7"
					value="non" checked="checked" onclick="hide('pignon7');"/> oui <input type="radio" id="WF33_facade_avec_pignon_7"
					name="WF33_facade_avec_pignon_7" value="oui"
					onclick="show('pignon7');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF33_Largeur_facade_7" name="WF33_Largeur_facade_7" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF33_Hauteur_facade_7" name="WF33_Hauteur_facade_7" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon7" style="display: none;">Hauteur pignon : <input type="text" size="5px" id="WF33_Hauteur_pignon_7"
					name="WF33_Hauteur_pignon_7" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface7" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF33_surface_facade_7"
					name="WF33_surface_facade_7" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			
			<tr id="facade8" style="display: none;">
				<td rowspan="2" class="PBStatic">Fa&ccedil;ade 8 :</td>
				<td>Pignon : non <input type="radio"
					id="WF34_facade_avec_pignon_8" name="WF34_facade_avec_pignon_8"
					value="non" checked="checked"
					onclick="hide('pignon8');cleart('Hauteur_pignon_8');"/> oui <input type="radio" id="WF34_facade_avec_pignon_8"
					name="WF34_facade_avec_pignon_8" value="oui"
					onclick="show('pignon8');"/></td>
				<td>Largeur : <input type="text" size="5px"
					id="WF34_Largeur_facade_8" name="WF34_Largeur_facade_8" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td>Hauteur : <input type="text" size="5px"
					id="WF34_Hauteur_facade_8" name="WF34_Hauteur_facade_8" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
				<td id="pignon8" style="display: none;">Hauteur pignon : <input type="text" size="5px" id="WF34_Hauteur_pignon_8"
					name="WF34_Hauteur_pignon_8" value="0" onFocus="if(this.value=='0')this.value=''"/></td>
			</tr>
			<tr id="surface8" style="display: none;">
				<td>OU surface totale de la fa&ccedil;ade</td>
				<td><input type="text" id="WF34_surface_facade_8"
					name="WF34_surface_facade_8" value="0" size="5px" onFocus="if(this.value=='0')this.value=''"/> m<sup>2</sup></td>
			</tr>
			<tr id="boutonsurface" style="display: table-row">
				<td colspan="3"><input type="button"
					value="calculer la surface totale des fa&ccedil;ades &agrave; traiter"
					onclick="show('infostravaux');show('zonesurfacetotale');calculSurface();hide('boutonsurface');disabfacade();"/></td>
			</tr>
			<tr id="zonesurfacetotale" align="right" style="display: none;">
				<td colspan="8">Surface totale des fa&ccedil;ades &agrave;
				traiter : <input type="text" id="WF35_Surface_totale"
					name="WF35_Surface_totale" value="0" size="5px"/> m<sup>2</sup></td>
			</tr>
		</table>
	</div>

</body>
</html>
